### What has been done

<!--
Which key changes does this PR provide?
-->

Updated recipe(s) mentioned in the PR title, as part of the release process for major TALY version.


### How to review

<!--
What steps are needed to setup the testing environment?
What scenarios need to be tested?
-->

<!--
Install locally built version of dependencies:

npm install PATH_TO_BUILT_DEP --install-links=true --legacy-peer-deps
-->

Follow the README of the updated recipe(s) and check if the described steps work as expected.
