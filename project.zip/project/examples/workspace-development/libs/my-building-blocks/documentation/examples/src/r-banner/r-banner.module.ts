import { NgModule } from '@angular/core';
import { AclModule } from '@allianz/taly-acl/angular';
import { ExampleRBannerComponent } from './r-banner.component';
import { RBannerModule } from 'my-building-blocks';

@NgModule({
  declarations: [ExampleRBannerComponent],
  imports: [AclModule, RBannerModule],
  exports: [ExampleRBannerComponent],
})
export class ExampleRBannerModule {
  static components() {
    return {
      ExampleRBannerComponent: ExampleRBannerComponent,
    };
  }
}
