import { Component } from '@angular/core';
import {
  RMyBuildingBlockResources,
  RMyBuildingBlockState,
} from 'my-building-blocks';

@Component({
  selector: 'example-r-my-building-block',
  templateUrl: 'r-my-building-block.component.html',
})
export class ExampleRMyBuildingBlockComponent {
  resourcesExample: RMyBuildingBlockResources = {
    resourcesData: 'Sample string in Resources',
  };
  stateExample: RMyBuildingBlockState = {
    person: {
      firstName: 'John',
      lastName: '',
    },
  };
}
