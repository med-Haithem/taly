import { NgModule } from '@angular/core';
import { AclModule } from '@allianz/taly-acl/angular';
import { ExampleRMyBuildingBlockComponent } from './r-my-building-block.component';
import { RMyBuildingBlockModule } from 'my-building-blocks';

@NgModule({
  declarations: [ExampleRMyBuildingBlockComponent],
  imports: [AclModule, RMyBuildingBlockModule],
  exports: [ExampleRMyBuildingBlockComponent],
})
export class ExampleRMyBuildingBlockModule {
  static components() {
    return {
      ExampleRMyBuildingBlockComponent: ExampleRMyBuildingBlockComponent,
    };
  }
}
