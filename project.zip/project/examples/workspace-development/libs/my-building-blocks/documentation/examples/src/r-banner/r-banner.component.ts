import { Component } from '@angular/core';
import { RBannerResources, RBannerState } from 'my-building-blocks';

@Component({
  selector: 'example-r-banner',
  templateUrl: 'r-banner.component.html',
})
export class ExampleRBannerComponent {
  resourcesExample: RBannerResources = {
    resourcesData: 'Sample string in Resources',
  };
  stateExample: RBannerState = {
    person: {
      firstName: 'John',
      lastName: '',
    },
  };
}
