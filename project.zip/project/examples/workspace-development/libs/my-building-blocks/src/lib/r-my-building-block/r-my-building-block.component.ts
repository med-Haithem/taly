import {
  AbstractBuildingBlock,
  createBuildingBlockProvider,
} from '@allianz/taly-core';
import { Component, forwardRef } from '@angular/core';

interface RMyBuildingBlockResources {
  title?: string;
}

@Component({
  selector: 'bb-r-my-building-block',
  templateUrl: 'r-my-building-block.component.html',
  styleUrls: ['r-my-building-block.component.scss'],
  providers: [
    createBuildingBlockProvider(forwardRef(() => RMyBuildingBlockComponent)),
  ],
})
export class RMyBuildingBlockComponent extends AbstractBuildingBlock<
  undefined,
  RMyBuildingBlockResources | undefined
> {
  override onPageConnection() {
    this.commitCompletion();
  }
}
