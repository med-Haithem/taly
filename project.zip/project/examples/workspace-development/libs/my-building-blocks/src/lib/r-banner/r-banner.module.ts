import { TalyCoreModule } from '@allianz/taly-core';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { NxGridModule } from '@aposin/ng-aquila/grid';
import { RBannerComponent } from './r-banner.component';

@NgModule({
  declarations: [RBannerComponent],
  imports: [CommonModule, ReactiveFormsModule, TalyCoreModule, NxGridModule],
  exports: [RBannerComponent],
})
export class RBannerModule {}
