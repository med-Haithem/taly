---
title: banner
lob:
  - any
channel:
  - expert
  - retail
---

## Purpose

This is a Building Block that is meant to be used as a page's bannerBlock.

<!-- example(r-banner) -->
