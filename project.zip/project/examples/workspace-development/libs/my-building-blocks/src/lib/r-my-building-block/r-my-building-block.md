---
title: MyBuildingBlock
lob:
  - any
channel:
  - expert
  - retail
---

## Purpose

This is a Building Block purely for demonstration purposes.

Did you know that, even though the "lorem ipsum" text is nonsense, it actually has a repeated phrase, "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit", meaning "Neither is there anyone who loves pain itself, who seeks after it and wants to have it, simply because it's pain".
