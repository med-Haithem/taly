import { TalyCoreModule } from '@allianz/taly-core';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { NxCopytextModule } from '@aposin/ng-aquila/copytext';
import { NxHeadlineModule } from '@aposin/ng-aquila/headline';
import { RMyBuildingBlockComponent } from './r-my-building-block.component';

@NgModule({
  declarations: [RMyBuildingBlockComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TalyCoreModule,
    NxHeadlineModule,
    NxCopytextModule,
  ],
  exports: [RMyBuildingBlockComponent],
})
export class RMyBuildingBlockModule {}
