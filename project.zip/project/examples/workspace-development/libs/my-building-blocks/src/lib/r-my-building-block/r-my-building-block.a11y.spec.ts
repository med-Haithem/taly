import { AclTestingModule } from '@allianz/taly-acl/testing';
import { render, RenderResult } from '@testing-library/angular';
import { axe } from 'jest-axe';
import {
  RMyBuildingBlockComponent,
  RMyBuildingBlockModule,
} from './public-api';

describe('Accessibility for Building Block MyBuildingBlock', () => {
  beforeAll(() => {
    console.warn = jest.fn();
  });

  afterAll(() => {
    jest.resetAllMocks();
  });

  async function renderComponent() {
    return render(RMyBuildingBlockComponent, {
      excludeComponentDeclaration: true,
      imports: [RMyBuildingBlockModule, AclTestingModule],
    });
  }

  test('MyBuildingBlock should be accessible', async () => {
    const renderResult: RenderResult<RMyBuildingBlockComponent> =
      await renderComponent();

    const results = await axe(renderResult.fixture.nativeElement);

    expect(results).toHaveNoViolations();
  });
});
