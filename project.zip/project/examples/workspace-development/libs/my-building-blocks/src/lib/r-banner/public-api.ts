export * from './r-banner.component';
export * from './r-banner.module';
