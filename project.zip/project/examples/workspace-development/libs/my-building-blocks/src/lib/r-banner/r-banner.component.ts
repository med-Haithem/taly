import {
  AbstractBuildingBlock,
  createBuildingBlockProvider,
} from '@allianz/taly-core';
import { Component, forwardRef } from '@angular/core';

@Component({
  selector: 'bb-r-banner',
  template: `<div nxLayout="grid nopadding">
    <div nxRow [rowJustify]="isExpertChannel ? 'start' : 'center'">
      <div [nxCol]="isExpertChannel ? '12,12' : '12,12,8'">
        <div
          style="display: flex; justify-content: space-between; align-items: center; color: white; font-size: 1.7em; min-height: 50px"
        >
          <div>Sticky Banner</div>
          <div>1.234,00 €</div>
        </div>
      </div>
    </div>
  </div>`,
  providers: [createBuildingBlockProvider(forwardRef(() => RBannerComponent))],
})
export class RBannerComponent extends AbstractBuildingBlock {
  override onPageConnection(): void {
    this.commitCompletion();
  }
}
