# my-building-blocks

Building Block library.

## Verifying production build

Run `npx nx build my-building-blocks` to build the library.

## Running unit tests

Run `npx nx test my-building-blocks` to execute the unit tests.

## Running accessibility tests

Run `npx nx test-accessibility my-building-blocks` to execute the accessibility tests.
