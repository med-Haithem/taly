# Example: workspace-development

This is an Nx workspace that contains a Building Block library as well as a journey configuration:

- `libs/my-building-blocks`: the Building Block library
- `apps/my-journey`: the journey (configuration)

It is meant to showcase a local development workflow when working in an Nx workspace. Essentially, this is a boiled-down version of mono-repositories like the `itmp-frontend-workspace`.

## Getting started

1. Install the dependencies

```sh
npm install
```

2. Generate the journal and introspection files for the Building Block library

```sh
npx nx journal my-building-blocks &&
npx nx introspection my-building-blocks
```

> 💡 Learn more about these executors here:
>
> - [The Journal executor](https://gdf-taly-workspace.azureedge.net/additional-documentation/building-block-development.html#the-journal-executor)
> - [The Introspection executor](https://gdf-taly-workspace.azureedge.net/additional-documentation/building-block-development.html#the-introspection-executor)

3. Start the journey

```sh
npx nx develop my-journey
```

4. Open the journey in the browser

Navigate to [http://localhost:4200](http://localhost:4200) to view the journey in your browser.

5. Edit the journey configuration or the Building Block

Change the Building Block code/template in `examples/workspace-development/libs/my-building-blocks/src/lib/r-my-building-block` or the journey configuration in the files in `examples/workspace-development/apps/my-journey/config` to witness live updates in the browser.
