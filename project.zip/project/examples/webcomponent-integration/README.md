# Generate Customer Journey as a Web Component

This recipe shows how to use the TALY `generate` executor to generate a customer journey as a web component.

See also [the TALY documentation](https://gdf-taly-workspace.azureedge.net/additional-documentation/app-generation/app-as-web-component.html).

## Quick start 🐇

1. Install the dependencies with `npm install --legacy-peer-deps`
2. Generate and serve the customer journey as a web component with `npm run start`.
3. In another terminal, start the host application with `npm run serve-wc-host` and visit http://localhost:4250 to see the generated journey in action.

----------------------------------------------------------------------

## Slow start 🦔

### Generating and serving the web component

Running `npm run start` script will prepare everything you need to get your web component built and served. The `start` script will execute 4 commands in sequence (see `package.json`). Let's take a deeper look at them:

**1. `generate-element`**

This script calls the `generate-only` architect, which uses the TALY `generate` executor to create a web component application from the configuration files.

Your journey will be generated with the `chromeless` flag (see `pages.json`), so it doesn't have a header and footer. Web components are mostly supposed to be embedded inside a host/portal that provides a header and footer itself (note the "HEADER OF HOST" and "FOOTER OF HOST" in the running example).

**2. `build-element`**

Once the application has been generated, it will be built using a dedicated `webcomponent` build configuration (see `build-generated-app` architect in `angular.json`). The output will be stored at `dist/customer-journey/en-US`.

**3. `bundle-element`**

The generated script `element-builder.js` will turn the build output into a single file called `webcomponent-bundle.js`. This file will be consumed by your host/portal website (see `app-shell/index.html`).

**4. `serve-element`**

Last but not least, your bundled web component will be served, making it accessible for the host application.

### Serving the host application

The host application is ready to consume the web component. All that needs to be done is to serve it by running the `npm run serve-wc-host` script, open the host app URL (http://localhost:4250) in the browser and see the web component being rendered.
