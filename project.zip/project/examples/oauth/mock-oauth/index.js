const { OAuth2Server } = require('oauth2-mock-server');

async function main() {
  let server = new OAuth2Server(undefined, undefined, {endpoints: "end_session"});

  // Generate a new RSA key and add it to the keystore
  await server.issuer.keys.generate('RS256');

  // Add custom token field for check on BFF side
  server.service.on('beforeTokenSigning', (token, _req) => {
    token.payload['oauth-recipe-test'] = 'i-am-john-doe';
  });

  // Custom end session handler to prevent error from 'oauth2-mock-server'
  // due to end session request from taly-oauth missing the query param 'post_logout_redirect_uri type'
  server.service.requestHandler.get("/end_session", (_req, res) => {
    return res
    .status(200)
    .send(JSON.stringify("Sucessfully logged out"));
  })

  // Start the server
  await server.start(4000, 'localhost');
  console.log('Issuer URL:', server.issuer.url);
}

main();

