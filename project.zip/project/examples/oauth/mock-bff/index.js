const express = require("express");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const authMiddleware = (req, res, next) => {
  if (!req.headers["authorization"]) {
    return res.status(401).send("No access token provided");
  }

  const accessToken = req.headers["authorization"].substr("Bearer ".length);
  // should actually be `.verify`, but we don't have the public key right now for that
  const accessTokenPayload = jwt.decode(accessToken);
  if (!accessTokenPayload) {
    return res.status(401).send("Invalid access token");
  }

  // somewhat random check to show that we have access to the token payload
  if (accessTokenPayload['oauth-recipe-test'] !== "i-am-john-doe") {
    return res
      .status(401)
      .send(`Access token payload check failed. \n Expected 'oauth-recipe-test' to be 'i-am-john-doe', but got ${accessTokenPayload['oauth-recipe-test']}`);
  }
  next();
};

const app = express();
app.use(cors());
app.get("/", (_, res) => res.send("Hello"));
app.get("/secret", authMiddleware, (_, res) => {
  console.log('- received a valid request to /secret ✔');
  res.send({ message: "This is a message from a secure backend that requires authentication." })
});

const port = 3000;
app.listen(port, () => console.log(`Mock-BFF listening at http://localhost:${port}...`));
