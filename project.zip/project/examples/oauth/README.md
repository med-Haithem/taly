# OAuth example

This example application showcases the usage of the `@allianz/taly-oauth` library in a generated app.

The most important parts are the configuration of the `OauthPfeIntegrationModule` as a plugin in `my-auth-app/config/pages.json` as well as the PFE config in `my-auth-app/config/pfe.json`.

## Getting started

1. Install dependencies:

    ```sh
    npm install
    ```

2. Generate and serve the application:

    ```sh
    npm start
    ```

3. Start the mock BFF. It will listen to [http://localhost:3000](http://localhost:3000)
    and has a `/secret` endpoint that will be called on the last page of the application.
    The endpoint verifies that there is an access token set and therefore serves as a
    proof of concept that the interception of HTTP requests in the frontend actually works:

    ```sh
    npm run mock-bff
    ```

4. Start the mock OAuth server. It will listen to [http://localhost:4000](http://localhost:4000)
   and it will handle all the requests coming from the `taly-oauth` library:

    ```sh
    npm run mock-oauth
    ```

5. Open [http://localhost:5500](http://localhost:5500) and click through the app. When clicking `Login`, the mock oauth server is going to do an automatic authentication (no login page) and redirect back to the app. Open the network tab of the browser dev tools (with preserve log) to follow the sequence. Navigating to the next page will trigger a call to the secret endpoint.
