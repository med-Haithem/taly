import {
  AbstractBuildingBlock,
  createBuildingBlockProvider,
} from '@allianz/taly-core';
import { Component, OnInit, forwardRef } from '@angular/core';

@Component({
  selector: 'bb-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css'],
  providers: [createBuildingBlockProvider(forwardRef(() => LogoutComponent))],
})
export class LogoutComponent extends AbstractBuildingBlock implements OnInit {
  public override id = 'bb-logout';

  override ngOnInit() {
    this.commitCompletion();
  }
}
