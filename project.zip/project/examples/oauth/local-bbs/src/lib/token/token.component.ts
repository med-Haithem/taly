import {
  AbstractBuildingBlock,
  createBuildingBlockProvider,
} from '@allianz/taly-core';
import { Component, OnInit, forwardRef } from '@angular/core';

interface TokenComponentResources {
  code: string;
  state: string;
  accessToken: string;
  idToken: string;
  refreshToken?: string;
}

@Component({
  selector: 'bb-oauth-token',
  templateUrl: './token.component.html',
  styleUrls: ['./token.component.css'],
  providers: [createBuildingBlockProvider(forwardRef(() => TokenComponent))],
})
export class TokenComponent
  extends AbstractBuildingBlock<{}, TokenComponentResources>
  implements OnInit
{
  public override id = 'bb-oauth-token';

  override ngOnInit(): void {
    this.commitCompletion();
  }
}
