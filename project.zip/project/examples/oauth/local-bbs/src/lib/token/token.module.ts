import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NxAccordionModule } from '@aposin/ng-aquila/accordion';
import { TokenComponent } from './token.component';

@NgModule({
  declarations: [TokenComponent],
  exports: [TokenComponent],
  imports: [
    CommonModule,
    NxAccordionModule
  ],
})
export class TokenModule {}
