import {
  AbstractBuildingBlock,
  createBuildingBlockProvider,
} from '@allianz/taly-core';
import { Component, OnInit, forwardRef } from '@angular/core';

@Component({
  selector: 'bb-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [createBuildingBlockProvider(forwardRef(() => LoginComponent))],
})
export class LoginComponent extends AbstractBuildingBlock implements OnInit {
  public override id = 'bb-login';

  override ngOnInit() {
    this.commitCompletion();
  }
}
