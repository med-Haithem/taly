import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SecretMessageComponent } from './secret-message.component';

@NgModule({
  declarations: [SecretMessageComponent],
  exports: [SecretMessageComponent],
  imports: [CommonModule],
})
export class SecretMessageModule {}
