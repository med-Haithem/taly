import {
  AbstractBuildingBlock,
  createBuildingBlockProvider,
} from '@allianz/taly-core';
import { Component, OnInit, forwardRef } from '@angular/core';

interface SecretMessageComponentResources {
  message: string;
}

@Component({
  selector: 'bb-secret-message',
  providers: [createBuildingBlockProvider(forwardRef(() => SecretMessageComponent))],
  template: `
    <h1 nxHeadline i18n>Secret received</h1>
    <strong>{{ resources?.message }}</strong>
  `,
})
export class SecretMessageComponent
  extends AbstractBuildingBlock<{}, SecretMessageComponentResources>
  implements OnInit
{
  public override id = 'secret-message';

  override ngOnInit(): void {
    this.commitCompletion();
  }
}
