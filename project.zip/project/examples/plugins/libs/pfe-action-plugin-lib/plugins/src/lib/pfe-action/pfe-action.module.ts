import { ModuleWithProviders, NgModule } from "@angular/core";
import { PfeActionService } from "./pfe-action";

@NgModule({
  providers: [PfeActionService],
})
export class PfeActionPluginModule {
  constructor(pfeActionService: PfeActionService) {
    pfeActionService.registerActions();
  }

  static forRoot(): ModuleWithProviders<PfeActionPluginModule> {
    return { ngModule: PfeActionPluginModule };
  }
}
