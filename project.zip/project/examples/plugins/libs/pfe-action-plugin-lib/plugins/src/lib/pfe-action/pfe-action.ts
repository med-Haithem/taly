import { PfeActionsService, PfeBusinessService } from "@allianz/ngx-pfe";
import { Injectable } from "@angular/core";

@Injectable()
export class PfeActionService {
  constructor(
    private pfeBusinessService: PfeBusinessService,
    private pfeActionService: PfeActionsService,
  ) {}

  registerActions() {
    this.pfeActionService.registerAction(
      "ADD_STORE_DUMMY_DATA",
      this.addStoreDummyDataAction.bind(this),
    );
  }

  private addStoreDummyDataAction(): Promise<void> {
    this.pfeBusinessService.storeValue("dummyData", { value: "dummy" });
    console.log("PfeActionPlugin:: stored dummy data in PFE store");
    return Promise.resolve();
  }
}
