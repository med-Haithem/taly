# validator-plugins-lib

Building Block library.

## Verifying production build

Run `npx nx build validator-plugins-lib` to build the library.

## Running unit tests

Run `npx nx test validator-plugins-lib` to execute the unit tests.

## Running accessibility tests

Run `npx nx test-accessibility validator-plugins-lib` to execute the accessibility tests.
