import { PluginValidator, PluginValidatorType } from "@allianz/taly-core";
import { Inject, Injectable } from "@angular/core";
import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";
import { EscapedMaxLengthValidatorPluginOptions } from "./escaped-max-length-validator.module";
import { ESCAPED_MAX_LENGTH_PLUGIN_OPTIONS } from "./tokens";

declare var $localize: any;

@Injectable({ providedIn: "root" })
export class EscapedMaxLengthValidator implements PluginValidator<number> {
  constructor(
    @Inject(ESCAPED_MAX_LENGTH_PLUGIN_OPTIONS)
    private options: EscapedMaxLengthValidatorPluginOptions
  ) {}

  // To be specified when configuring this validator for a form field
  type: PluginValidatorType = "PLUGIN_MYTEAM_ESCAPED_MAX_LENGTH";

  defaultErrorMessage = "";

  private _setDefaultErrorMessage(max: number) {
    this.defaultErrorMessage = $localize`:@@validation.error.escapedMaxLengthValidator:This field should not contain more than ${max} characters`;
  }

  validate(
    escapedMaxLength: number = this.options.escapedMaxLength
  ): ValidatorFn {
    console.log(
      "EscapedMaxLengthValidator: escapedMaxLength:",
      escapedMaxLength
    );

    this._setDefaultErrorMessage(escapedMaxLength);

    return (control: AbstractControl): ValidationErrors | null => {
      if (!control.value) {
        return null;
      }

      const actualValue = JSON.stringify(control.value).slice(0, -1).substr(1);

      if (actualValue.length > escapedMaxLength) {
        return {
          [this.type]: true,
        };
      }

      return null;
    };
  }
}
