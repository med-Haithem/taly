import { InjectionToken } from "@angular/core";
import { EscapedMaxLengthValidatorPluginOptions } from "./escaped-max-length-validator.module";

export const ESCAPED_MAX_LENGTH_PLUGIN_OPTIONS =
  new InjectionToken<EscapedMaxLengthValidatorPluginOptions>(
    "ESCAPED_MAX_LENGTH_PLUGIN_OPTIONS"
  );
