import { PluginValidator, PluginValidatorType } from "@allianz/taly-core";
import { Injectable } from "@angular/core";
import { AbstractControl, ValidationErrors, ValidatorFn } from "@angular/forms";

declare var $localize: any;

@Injectable({ providedIn: "root" })
export class ThaiIdNumberValidator implements PluginValidator {
  // To be specified when configuring this validator for a form field
  type: PluginValidatorType = "PLUGIN_MYTEAM_THAI_ID_NUMBER";

  defaultErrorMessage = $localize`:@@validation.error.thaiIdNumber:Please enter a valid Thai id number`;

  // Implementation taken from https://gist.github.com/layerlre/a8cffb2713089235062334cb07e653bd
  validate(): ValidatorFn {
    // Valid Id numbers: (http://lertsirikarn.blogspot.com/p/thai-id-number-generator.html)
    return (control: AbstractControl): ValidationErrors | null => {
      let validLength = true;
      let validNumericValue = true;

      if (control.value.length != 13) {
        validLength = false;
      }

      let sum = 0;
      for (let i = 0; i < 12; i++) {
        sum += parseInt(control.value.charAt(i), 36) * (13 - i);
      }
      validNumericValue =
        (11 - (sum % 11)) % 10 == parseInt(control.value.charAt(12), 36);

      if (validLength && validNumericValue) {
        return null;
      }

      return { [this.type]: true };
    };
  }
}
