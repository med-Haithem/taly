import { PLUGIN_VALIDATORS } from "@allianz/taly-core";
import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { ThaiIdNumberValidator } from "./thai-id-number-validator";

@NgModule({
  providers: [
    {
      provide: PLUGIN_VALIDATORS,
      useClass: ThaiIdNumberValidator,
      multi: true,
    },
  ],
  imports: [CommonModule],
})
export class ThaiIdNumberValidatorModule {
  static forRoot(): ModuleWithProviders<ThaiIdNumberValidatorModule> {
    return { ngModule: ThaiIdNumberValidatorModule };
  }
}
