import { PLUGIN_VALIDATORS } from "@allianz/taly-core";
import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { EscapedMaxLengthValidator } from "./escaped-max-length-validator";
import { ESCAPED_MAX_LENGTH_PLUGIN_OPTIONS } from "./tokens";

const DEFAULT_OPTIONS: EscapedMaxLengthValidatorPluginOptions = {
  escapedMaxLength: 30,
};

export interface EscapedMaxLengthValidatorPluginOptions {
  escapedMaxLength: number;
  customField?: TestInterface;
}

export interface TestInterface {
  subfield1: TestInterface2;
  bla: string;
  blu: Date;
}

export interface TestInterface2 {
  subsubfield1: string[];
}

@NgModule({
  providers: [
    {
      provide: PLUGIN_VALIDATORS,
      useClass: EscapedMaxLengthValidator,
      multi: true,
    },
  ],
  imports: [CommonModule],
})
export class EscapedMaxLengthValidatorModule {
  static forRoot(
    options: EscapedMaxLengthValidatorPluginOptions = DEFAULT_OPTIONS,
  ): ModuleWithProviders<EscapedMaxLengthValidatorModule> {
    return {
      ngModule: EscapedMaxLengthValidatorModule,
      providers: [
        { provide: ESCAPED_MAX_LENGTH_PLUGIN_OPTIONS, useValue: options },
      ],
    };
  }
}
