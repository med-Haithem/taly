# plugins-recipe-building-blocks

Building Block library.

## Verifying production build

Run `npx nx build plugins-recipe-building-blocks` to build the library.

## Running unit tests

Run `npx nx test plugins-recipe-building-blocks` to execute the unit tests.

## Running accessibility tests

Run `npx nx test-accessibility plugins-recipe-building-blocks` to execute the accessibility tests.
