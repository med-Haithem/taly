import { Component } from "@angular/core";
import {
  RecipeFormWithCustomValidatorResources,
  RecipeFormWithCustomValidatorState,
} from "plugins-recipe-building-blocks";

@Component({
  selector: "example-recipe-form-with-custom-validator",
  templateUrl: "recipe-form-with-custom-validator.component.html",
})
export class ExampleRecipeFormWithCustomValidatorComponent {
  resourcesExample: RecipeFormWithCustomValidatorResources = {
    resourcesData: "Sample string in Resources",
  };
  stateExample: RecipeFormWithCustomValidatorState = {
    personalDetails: {
      idNumber: "1234567890",
      postalCode: "12345",
      streetName: "Sample Street",
    },
  };
}
