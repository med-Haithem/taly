import { AclModule } from "@allianz/taly-acl/angular";
import { NgModule } from "@angular/core";
import { RecipeFormWithCustomValidatorModule } from "../../../../src/lib/recipe-form-with-custom-validator/public-api";
import { ExampleRecipeFormWithCustomValidatorComponent } from "./recipe-form-with-custom-validator.component";

@NgModule({
  declarations: [ExampleRecipeFormWithCustomValidatorComponent],
  imports: [AclModule, RecipeFormWithCustomValidatorModule],
  exports: [ExampleRecipeFormWithCustomValidatorComponent],
})
export class ExampleRecipeFormWithCustomValidatorModule {
  static components() {
    return {
      ExampleRecipeFormWithCustomValidatorComponent:
        ExampleRecipeFormWithCustomValidatorComponent,
    };
  }
}
