import { AclModule } from "@allianz/taly-acl/angular";
import { NgModule } from "@angular/core";
import { RecipePlaceholderModule } from "../../../../src/lib/recipe-placeholder/public-api";
import { ExampleRecipePlaceholderComponent } from "./recipe-placeholder.component";

@NgModule({
  declarations: [ExampleRecipePlaceholderComponent],
  imports: [AclModule, RecipePlaceholderModule],
  exports: [ExampleRecipePlaceholderComponent],
})
export class ExampleRecipePlaceholderModule {
  static components() {
    return {
      ExampleRecipePlaceholderComponent: ExampleRecipePlaceholderComponent,
    };
  }
}
