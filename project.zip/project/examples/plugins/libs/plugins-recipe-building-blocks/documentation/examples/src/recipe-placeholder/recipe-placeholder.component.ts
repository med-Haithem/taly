import { Component } from "@angular/core";
import {
  RecipePlaceholderResources,
  RecipePlaceholderState,
} from "plugins-recipe-building-blocks";

@Component({
  selector: "example-recipe-placeholder",
  templateUrl: "recipe-placeholder.component.html",
})
export class ExampleRecipePlaceholderComponent {
  resourcesExample: RecipePlaceholderResources = {
    resourcesData: "Sample string in Resources",
  };
  stateExample: RecipePlaceholderState = {
    person: {
      firstName: "John",
      lastName: "",
    },
  };
}
