import { BuildingBlockExampleData } from "@allianz/taly-core/showroom";
import { RecipePlaceholderResources } from "./recipe-placeholder.model";

export const recipePlaceholderExampleData: BuildingBlockExampleData<
  undefined,
  RecipePlaceholderResources
> = {
  default: {
    resources: {
      purpose: "Placeholder's purpose",
    },
  },
};
