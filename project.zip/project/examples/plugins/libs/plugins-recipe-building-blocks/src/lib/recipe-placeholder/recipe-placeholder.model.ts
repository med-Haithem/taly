export interface RecipePlaceholderResources {
  purpose: string;
}
