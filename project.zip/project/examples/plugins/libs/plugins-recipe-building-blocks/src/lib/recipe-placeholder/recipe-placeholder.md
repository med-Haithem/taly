---
title: placeholder
lob:
  - any
channel:
  - expert
  - retail
---

## Purpose

Use this schematic whenever you are creating a new Building Block. This will give you all the basic boilerplate you need to setup your Building Block for free. In addition, we don't need to review the generated code any more, since this is already done.

<!-- example(placeholder) -->
