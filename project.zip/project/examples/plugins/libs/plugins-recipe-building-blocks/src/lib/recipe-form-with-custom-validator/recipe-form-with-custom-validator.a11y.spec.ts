import { AclTestingModule } from "@allianz/taly-acl/testing";
import { render, RenderResult } from "@testing-library/angular";
import { axe } from "jest-axe";
import {
  RecipeFormWithCustomValidatorComponent,
  RecipeFormWithCustomValidatorModule,
} from "./public-api";

describe("Accessibility for Building Block Form With Custom Validator", () => {
  beforeAll(() => {
    console.warn = jest.fn();
  });

  afterAll(() => {
    jest.resetAllMocks();
  });

  async function renderComponent() {
    return render(RecipeFormWithCustomValidatorComponent, {
      excludeComponentDeclaration: true,
      imports: [RecipeFormWithCustomValidatorModule, AclTestingModule],
    });
  }

  test("Form With Custom Validator should be accessible", async () => {
    const renderResult: RenderResult<RecipeFormWithCustomValidatorComponent> =
      await renderComponent();

    const results = await axe(renderResult.fixture.nativeElement);

    expect(results).toHaveNoViolations();
  });
});
