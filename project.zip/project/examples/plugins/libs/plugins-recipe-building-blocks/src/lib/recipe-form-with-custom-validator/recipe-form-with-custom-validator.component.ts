import {
  autoFormBindingFactory,
  FormBindingReturnValue,
} from "@allianz/taly-acl/form-support";
import {
  AbstractBuildingBlock,
  applyValidationConfig,
  createBuildingBlockProvider,
  ValidationConfig,
} from "@allianz/taly-core";
import {
  Component,
  DestroyRef,
  forwardRef,
  inject,
  OnInit,
} from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { FormControl, FormGroup } from "@angular/forms";
import { map, tap } from "rxjs/operators";
import {
  RecipeFormWithCustomValidatorResources,
  RecipeFormWithCustomValidatorState,
} from "./recipe-form-with-custom-validator.model";

const bindAclWithForm = autoFormBindingFactory();

@Component({
  selector: "bb-form-with-custom-validator",
  templateUrl: "recipe-form-with-custom-validator.component.html",
  styleUrls: ["recipe-form-with-custom-validator.component.scss"],
  providers: [
    createBuildingBlockProvider(
      forwardRef(() => RecipeFormWithCustomValidatorComponent),
    ),
  ],
})
export class RecipeFormWithCustomValidatorComponent
  extends AbstractBuildingBlock<
    RecipeFormWithCustomValidatorState,
    RecipeFormWithCustomValidatorResources
  >
  implements OnInit
{
  private destroyRef = inject(DestroyRef);
  formGroup = new FormGroup({
    personalDetails: new FormGroup({
      idNumber: new FormControl("6123922063509"),
      postalCode: new FormControl(""),
      streetName: new FormControl(""),
    }),
  });

  validationMap?: Map<string, ValidationConfig[]>;
  aclFormBinding!: FormBindingReturnValue;

  override ngOnInit() {
    this.setupAclBinding();
    this.setupCompletionSubscription();
  }

  override setValidationConfiguration(data: any[]) {
    this.validationMap = applyValidationConfig(this.formGroup, data);
  }

  setupAclBinding() {
    this.aclFormBinding = bindAclWithForm(this.acl, this.formGroup);
    this.aclFormBinding.stream$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe();
  }

  setupCompletionSubscription() {
    this.formGroup.statusChanges
      .pipe(
        takeUntilDestroyed(this.destroyRef),
        map((status: string) => status === "VALID"),
        tap((valid: boolean) => {
          this.stateChanged();
          valid ? this.commitCompletion() : this.revertCompletion();
        }),
      )
      .subscribe();
  }

  override setResources(data: RecipeFormWithCustomValidatorResources) {
    console.log("Resources: ", data);
  }

  override setState(data: RecipeFormWithCustomValidatorState) {
    this.formGroup.patchValue(data);
  }

  override getState(): RecipeFormWithCustomValidatorState {
    return this.formGroup.getRawValue();
  }
}
