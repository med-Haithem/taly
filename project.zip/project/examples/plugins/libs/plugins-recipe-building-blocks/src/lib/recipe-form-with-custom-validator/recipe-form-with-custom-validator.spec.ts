import { FormGroup } from "@angular/forms";
import { render, RenderResult } from "@testing-library/angular";
import userEvent from "@testing-library/user-event";
import { AclTestingModule } from "@allianz/taly-acl/testing";
import {
  RecipeFormWithCustomValidatorComponent,
  RecipeFormWithCustomValidatorModule,
} from "./public-api";
import { fakeAsync, tick } from "@angular/core/testing";

async function renderComponent() {
  return render(RecipeFormWithCustomValidatorComponent, {
    excludeComponentDeclaration: true,
    imports: [RecipeFormWithCustomValidatorModule, AclTestingModule],
  });
}

describe("RecipeFormWithCustomValidatorComponent", () => {
  let renderResult: RenderResult<RecipeFormWithCustomValidatorComponent>;
  let buildingBlock: RecipeFormWithCustomValidatorComponent;

  beforeEach(async () => {
    renderResult = await renderComponent();
    buildingBlock = renderResult.fixture.debugElement.componentInstance;
    buildingBlock.setResources({
      resourcesData: "Sample string",
    });

    renderResult.fixture.detectChanges();
  });

  test("should render", async () => {
    expect(renderResult.container).toBeTruthy();
  });

  test("should include a title", async () => {
    const title = renderResult.getByText("Form With Custom Validator");
    expect(title).toBeTruthy();
  });

  describe("ACL", () => {
    afterEach(() => {
      AclTestingModule.reset();
    });

    describe("Hide", () => {
      function expectCanBeHidden(testId: string, aclTag = testId) {
        expect(renderResult.getByTestId(testId)).toBeInTheDocument();

        AclTestingModule.setHidden(aclTag, true);
        renderResult.fixture.detectChanges();

        expect(renderResult.queryByTestId(testId)).not.toBeInTheDocument();
      }

      const aclHideResources = [
        "headline",
        "subheadline",
        "person",
        "person/first-name",
        "person/last-name",
      ];

      test.each(aclHideResources)(
        'should allow to hide ACL resource "%s"',
        (aclResource) => expectCanBeHidden(aclResource),
      );
    });

    describe("Disable", () => {
      function expectCanBeDisabled(testId: string, aclTag = testId) {
        expect(renderResult.getByTestId(testId)).toBeEnabled();

        AclTestingModule.setDisabled(aclTag, true);
        renderResult.fixture.detectChanges();

        expect(renderResult.getByTestId(testId)).toBeDisabled();
      }

      const aclDisableResources = ["person/first-name", "person/last-name"];

      test.each(aclDisableResources)(
        'should allow to disable ACL resource "%s"',
        (aclResource) => expectCanBeDisabled(aclResource),
      );
    });

    describe("Readonly", () => {
      function expectCanBeMadeReadonly(testId: string, aclTag = testId) {
        expect(renderResult.getByTestId(testId)).not.toHaveAttribute(
          "readonly",
        );

        AclTestingModule.setReadonly(aclTag, true);
        tick(1);
        renderResult.fixture.detectChanges();

        expect(renderResult.getByTestId(testId)).toHaveAttribute("readonly");
      }

      const aclReadonlyResources = ["person/first-name", "person/last-name"];

      test.each(aclReadonlyResources)(
        'should allow to make ACL resource "%s" readonly',
        fakeAsync((aclResource: string) =>
          expectCanBeMadeReadonly(aclResource),
        ),
      );
    });
  });

  describe("Building Block Interface", () => {
    test("allows to set the state", () => {
      const firstNameInput = renderResult.getByTestId(
        "person/first-name",
      ) as HTMLInputElement;
      const lastNameInput = renderResult.getByTestId(
        "person/last-name",
      ) as HTMLInputElement;

      buildingBlock.setState({
        person: { firstName: "John", lastName: "Doe" },
      });

      expect(firstNameInput.value).toBe("John");
      expect(lastNameInput.value).toBe("Doe");
    });

    test("allows to get the state", async () => {
      const firstNameInput = renderResult.getByTestId(
        "person/first-name",
      ) as HTMLInputElement;
      const lastNameInput = renderResult.getByTestId(
        "person/last-name",
      ) as HTMLInputElement;

      await userEvent.type(firstNameInput, "John");
      await userEvent.type(lastNameInput, "Doe");

      expect(buildingBlock.getState()).toEqual({
        person: { firstName: "John", lastName: "Doe" },
      });
    });

    test("allows to set a validation configuration and displays the error message", async () => {
      buildingBlock.setValidationConfiguration([
        {
          id: "person.lastName",
          type: "MIN_LENGTH",
          minLength: 5,
          errorMessage: "The last name has to be at least 5 characters long",
        },
      ]);
      const lastNameInput = renderResult.getByTestId(
        "person/last-name",
      ) as HTMLInputElement;

      await userEvent.type(lastNameInput, "Frey");
      await userEvent.tab();
      renderResult.fixture.detectChanges();

      const errorMessageLastName = renderResult.getByTestId("last-name-errors");
      expect(errorMessageLastName).toHaveTextContent(
        "The last name has to be at least 5 characters long",
      );

      await userEvent.type(lastNameInput, "Freitag");
      await userEvent.tab();
      renderResult.fixture.detectChanges();

      expect(renderResult.queryByTestId("last-name-errors")).toBeNull();
    });

    test("marks itself as complete depending on the validity of the form", async () => {
      let completed = false;
      buildingBlock.setValidationConfiguration([
        {
          id: "person.firstName",
          type: "REQUIRED",
        },
      ]);
      buildingBlock.completion$.subscribe((value) => (completed = value));
      const firstNameInput = renderResult.getByTestId(
        "person/first-name",
      ) as HTMLInputElement;

      await userEvent.type(firstNameInput, "John");
      expect(completed).toBe(true);

      await userEvent.clear(firstNameInput);
      expect(completed).toBe(false);
    });

    test("implements getForm() method", () => {
      const form = buildingBlock.getForm();
      expect(form).toBeInstanceOf(FormGroup);
    });

    test("updates the completion state in onPageConnection()", async () => {
      buildingBlock.revertCompletion();
      expect(buildingBlock.completion$.value).toBe(false);

      buildingBlock.onPageConnection();
      expect(buildingBlock.completion$.value).toBe(true);
    });
  });
});
