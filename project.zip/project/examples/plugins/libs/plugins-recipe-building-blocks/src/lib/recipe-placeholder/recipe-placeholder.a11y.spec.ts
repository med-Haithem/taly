import { AclTestingModule } from "@allianz/taly-acl/testing";
import { render, RenderResult } from "@testing-library/angular";
import { axe } from "jest-axe";
import {
  RecipePlaceholderComponent,
  RecipePlaceholderModule,
} from "./public-api";

describe("Accessibility for Building Block Placeholder", () => {
  beforeAll(() => {
    console.warn = jest.fn();
  });

  afterAll(() => {
    jest.resetAllMocks();
  });

  async function renderComponent() {
    return render(RecipePlaceholderComponent, {
      excludeComponentDeclaration: true,
      imports: [RecipePlaceholderModule, AclTestingModule],
    });
  }

  test("Placeholder should be accessible", async () => {
    const renderResult: RenderResult<RecipePlaceholderComponent> =
      await renderComponent();

    const results = await axe(renderResult.fixture.nativeElement);

    expect(results).toHaveNoViolations();
  });
});
