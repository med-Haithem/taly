import { BuildingBlockExampleData } from "@allianz/taly-core/showroom";

import {} from "./recipe-form-with-custom-validator.component";
import {
  RecipeFormWithCustomValidatorResources,
  RecipeFormWithCustomValidatorState,
} from "./recipe-form-with-custom-validator.model";

export const recipeFormWithCustomValidatorExampleData: BuildingBlockExampleData<
  RecipeFormWithCustomValidatorState,
  RecipeFormWithCustomValidatorResources
> = {
  default: {
    resources: {
      resourcesData: "Resources data",
    },
    state: {
      personalDetails: {
        idNumber: "6123922063509",
        postalCode: "12345",
        streetName: "Str",
      },
    },
  },
};
