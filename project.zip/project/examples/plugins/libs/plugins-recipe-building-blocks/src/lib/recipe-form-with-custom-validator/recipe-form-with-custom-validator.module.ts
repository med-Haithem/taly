import { ValidationErrorsModule } from "@allianz/taly-common/validation-errors";
import { AclModule } from "@allianz/taly-acl/angular";
import { TalyCoreModule } from "@allianz/taly-core";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { NxFormfieldModule } from "@aposin/ng-aquila/formfield";
import { NxGridModule } from "@aposin/ng-aquila/grid";
import { NxHeadlineModule } from "@aposin/ng-aquila/headline";
import { NxInputModule } from "@aposin/ng-aquila/input";
import { RecipeFormWithCustomValidatorComponent } from "./recipe-form-with-custom-validator.component";

@NgModule({
  declarations: [RecipeFormWithCustomValidatorComponent],
  imports: [
    AclModule,
    CommonModule,
    TalyCoreModule,
    NxHeadlineModule,
    NxGridModule,
    NxFormfieldModule,
    NxInputModule,
    ReactiveFormsModule,
    ValidationErrorsModule,
  ],
  exports: [RecipeFormWithCustomValidatorComponent],
})
export class RecipeFormWithCustomValidatorModule {}
