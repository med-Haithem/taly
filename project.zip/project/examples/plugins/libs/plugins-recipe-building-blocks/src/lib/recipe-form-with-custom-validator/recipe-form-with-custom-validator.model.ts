export interface RecipeFormWithCustomValidatorResources {
  resourcesData: string;
}

export interface RecipeFormWithCustomValidatorState {
  personalDetails: {
    idNumber: string | null;
    postalCode: string | null;
    streetName: string | null;
  };
}
