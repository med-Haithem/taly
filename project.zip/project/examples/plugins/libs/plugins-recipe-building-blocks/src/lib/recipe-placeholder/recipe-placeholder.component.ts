import { Component, forwardRef, OnInit } from "@angular/core";
import {
  AbstractBuildingBlock,
  createBuildingBlockProvider,
} from "@allianz/taly-core";
import { RecipePlaceholderResources } from "./recipe-placeholder.model";

@Component({
  selector: "bb-placeholder",
  templateUrl: "recipe-placeholder.component.html",
  styleUrls: ["recipe-placeholder.component.scss"],
  providers: [
    createBuildingBlockProvider(forwardRef(() => RecipePlaceholderComponent)),
  ],
})
export class RecipePlaceholderComponent
  extends AbstractBuildingBlock<undefined, RecipePlaceholderResources>
  implements OnInit
{
  override onPageConnection() {
    this.commitCompletion();
  }
}
