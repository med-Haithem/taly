import { PLUGIN_VALIDATORS } from "@allianz/taly-core";
import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { PostalCodeValidator } from "./postal-code-validator";

@NgModule({
  providers: [
    {
      provide: PLUGIN_VALIDATORS,
      useClass: PostalCodeValidator,
      multi: true,
    },
  ],
  imports: [CommonModule],
})
export class PostalCodeValidatorModule {
  static forRoot(): ModuleWithProviders<PostalCodeValidatorModule> {
    return { ngModule: PostalCodeValidatorModule };
  }
}
