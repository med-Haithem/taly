import {
  AsyncPluginValidator,
  BFF_BASE_URL_TOKEN,
  PluginValidatorType,
} from "@allianz/taly-core";
import { HttpClient } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import {
  AbstractControl,
  AsyncValidatorFn,
  ValidationErrors,
} from "@angular/forms";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";

declare var $localize: any;

interface CustomPluginValidationParam {
  logText: string;
}

@Injectable({ providedIn: "root" })
export class PostalCodeValidator
  implements AsyncPluginValidator<CustomPluginValidationParam>
{
  constructor(
    private http: HttpClient,
    @Inject(BFF_BASE_URL_TOKEN) private baseUrl: string
  ) {}

  // To be specified when configuring this validator for a form field
  type: PluginValidatorType = "PLUGIN_MYTEAM_POSTAL_CODE";

  private interpolationString = "a valid";
  defaultErrorMessage = $localize`:@@validation.error.postalCode:Please enter ${this.interpolationString} postal code, which consists of 5 digits`;

  validateAsync(
    validationParam: CustomPluginValidationParam | undefined
  ): AsyncValidatorFn {
    console.log(validationParam?.logText);
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      const reqBody = {
        inputValue: control.value,
      };
      return this.http
        .post(`${this.baseUrl}/validate-postal-code`, reqBody)
        .pipe(
          map((res: { [key: string]: any }) => {
            return res["error"] ? { [this.type]: true } : null;
          })
        );
    };
  }
}
