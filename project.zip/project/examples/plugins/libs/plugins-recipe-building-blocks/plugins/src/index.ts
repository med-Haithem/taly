export * from './lib/postal-code-validator/postal-code-validator.module';
