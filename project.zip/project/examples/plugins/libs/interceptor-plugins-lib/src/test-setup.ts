import '@testing-library/jest-dom';
import 'jest-preset-angular/setup-jest';
import { TextEncoder } from 'util';

global.TextEncoder = TextEncoder;