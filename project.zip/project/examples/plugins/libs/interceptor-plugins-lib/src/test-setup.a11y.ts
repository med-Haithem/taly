import 'jest-preset-angular/setup-jest';
import 'jest-axe/extend-expect';
import { TextEncoder } from 'util';

global.TextEncoder = TextEncoder;