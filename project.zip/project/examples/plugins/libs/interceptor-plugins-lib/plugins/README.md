# Plugins

## Extract plugins metadata

Run `npx nx extract-plugin-metadata interceptor-plugins-lib`

For more information about the plugins feature, please take a look at the [TALY Plugins documentation](https://taly.frameworks.allianz.io/additional-documentation/plugins.html).
