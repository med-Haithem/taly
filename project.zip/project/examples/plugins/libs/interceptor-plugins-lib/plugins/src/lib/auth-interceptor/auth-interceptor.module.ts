import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { AuthInterceptor } from "./auth-interceptor";
import { AUTH_INTERCEPTOR_PLUGIN_OPTIONS } from "./tokens";

export interface AuthInterceptorPluginOptions {
  auth: {
    tokenType: string;
    accessToken: string;
  };
  foo: string;
}

const DEFAULT_OPTIONS: AuthInterceptorPluginOptions = {
  auth: {
    tokenType: "bearer",
    accessToken: "invalid",
  },
  foo: "bar",
};

@NgModule({
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
  ],
})
export class AuthInterceptorPluginModule {
  static forRoot(
    options: AuthInterceptorPluginOptions = DEFAULT_OPTIONS,
  ): ModuleWithProviders<AuthInterceptorPluginModule> {
    return {
      ngModule: AuthInterceptorPluginModule,
      providers: [
        { provide: AUTH_INTERCEPTOR_PLUGIN_OPTIONS, useValue: options },
      ],
    };
  }
}
