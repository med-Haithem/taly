import { InjectionToken } from "@angular/core";
import { AuthInterceptorPluginOptions } from "./auth-interceptor.module";

export const AUTH_INTERCEPTOR_PLUGIN_OPTIONS =
  new InjectionToken<AuthInterceptorPluginOptions>(
    "AUTH_INTERCEPTOR_PLUGIN_OPTIONS",
  );
