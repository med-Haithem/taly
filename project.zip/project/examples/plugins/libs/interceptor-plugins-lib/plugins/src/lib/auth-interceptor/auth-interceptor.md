---
type: plugin
title: Auth Interceptor
description: A description for Auth Interceptor
---
