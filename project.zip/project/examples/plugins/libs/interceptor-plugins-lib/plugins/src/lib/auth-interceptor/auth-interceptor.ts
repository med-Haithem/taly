import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AuthInterceptorPluginOptions } from "./auth-interceptor.module";
import { AUTH_INTERCEPTOR_PLUGIN_OPTIONS } from "./tokens";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    @Inject(AUTH_INTERCEPTOR_PLUGIN_OPTIONS)
    private options: AuthInterceptorPluginOptions
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const secureRequest = request.clone({
      headers: request.headers.set(
        "Authorization",
        `${this.options.auth.tokenType} ${this.options.auth.accessToken}`
      ),
    });

    console.log("AuthInterceptor::AuthInterceptorPluginOptions", this.options);

    // send the cloned, "secure" request to the next handler
    return next.handle(secureRequest);
  }
}
