import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { LanguageInterceptor } from "./language-interceptor";
import { LANGUAGE_INTERCEPTOR_PLUGIN_OPTIONS } from "./tokens";

export interface LanguageInterceptorPluginOptions {
  language: string;
}

@NgModule({
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: LanguageInterceptor,
    multi: true,
  }]
})
export class LanguageInterceptorPluginModule {
  static forRoot(options?: LanguageInterceptorPluginOptions): ModuleWithProviders<LanguageInterceptorPluginModule> {
    return {
      ngModule: LanguageInterceptorPluginModule,
      providers: [
        { provide: LANGUAGE_INTERCEPTOR_PLUGIN_OPTIONS, useValue: options }
      ],
    };
  }
}
