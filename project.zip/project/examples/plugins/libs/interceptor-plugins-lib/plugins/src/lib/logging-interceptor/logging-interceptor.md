---
type: plugin
title: Logging Interceptor
description: A description for Logging Interceptor
---
