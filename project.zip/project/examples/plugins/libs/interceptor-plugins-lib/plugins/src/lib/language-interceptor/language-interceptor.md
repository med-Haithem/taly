---
type: plugin
title: Language Interceptor
description: A description for Language Interceptor
---
