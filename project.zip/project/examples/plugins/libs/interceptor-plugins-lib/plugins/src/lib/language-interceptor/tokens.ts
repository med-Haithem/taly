import { InjectionToken } from "@angular/core";
import { LanguageInterceptorPluginOptions } from "./language-interceptor.module";

export const LANGUAGE_INTERCEPTOR_PLUGIN_OPTIONS =
  new InjectionToken<LanguageInterceptorPluginOptions>(
    "LANGUAGE_INTERCEPTOR_PLUGIN_OPTIONS",
  );
