import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { LoggingInterceptor } from "./logging-interceptor";

@NgModule({
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoggingInterceptor,
      multi: true,
    },
  ],
})
export class LoggingInterceptorPluginModule {
  static forRoot(): ModuleWithProviders<LoggingInterceptorPluginModule> {
    return { ngModule: LoggingInterceptorPluginModule };
  }
}
