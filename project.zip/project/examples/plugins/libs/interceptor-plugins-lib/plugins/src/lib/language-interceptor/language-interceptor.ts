import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from "@angular/common/http";
import { Inject, Injectable, LOCALE_ID } from "@angular/core";
import { Observable } from "rxjs";
import { LanguageInterceptorPluginOptions } from './language-interceptor.module';
import { LANGUAGE_INTERCEPTOR_PLUGIN_OPTIONS } from './tokens';

@Injectable()
export class LanguageInterceptor implements HttpInterceptor {
  constructor(
    @Inject(LOCALE_ID) private locale: string,
    @Inject(LANGUAGE_INTERCEPTOR_PLUGIN_OPTIONS) private options?: LanguageInterceptorPluginOptions,
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const clonedRequest = request.clone({
      headers: request.headers.set("Language", this.options?.language || this.locale),
    });

    console.log("LanguageInterceptor::LanguageInterceptorPluginOptions", this.options);

    // send the cloned request with the Language header to the next handler
    return next.handle(clonedRequest);
  }
}
