# interceptor-plugins-lib

Building Block library.

## Verifying production build

Run `npx nx build interceptor-plugins-lib` to build the library.

## Running unit tests

Run `npx nx test interceptor-plugins-lib` to execute the unit tests.

## Running accessibility tests

Run `npx nx test-accessibility interceptor-plugins-lib` to execute the accessibility tests.
