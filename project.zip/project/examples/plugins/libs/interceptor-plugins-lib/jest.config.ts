export default {
  preset: '../../jest.preset.js',
  testPathIgnorePatterns: ['/node_modules/'],
  testMatch: ['**/+(*.)+(spec|test).+(ts|js)?(x)', '!**/+(*.)a11y.+(spec|test).+(ts|js)?(x)'],
  snapshotSerializers: [
    'jest-preset-angular/build/serializers/no-ng-attributes',
    'jest-preset-angular/build/serializers/ng-snapshot',
    'jest-preset-angular/build/serializers/html-comment'
  ],
  setupFiles: ['@angular/localize/init'],
  setupFilesAfterEnv: ['<rootDir>/src/test-setup.ts'],
  displayName: 'interceptor-plugins-lib',
  transform: {
    '^.+\\.(ts|mjs|js|html)$': [
      'jest-preset-angular',
      {
        tsconfig: '<rootDir>/tsconfig.spec.json',
        stringifyContentPathRegex: '\\.(html|svg)$',
      },
    ],
  },
  transformIgnorePatterns: ['node_modules/(?!.*\\.mjs$)']
};
