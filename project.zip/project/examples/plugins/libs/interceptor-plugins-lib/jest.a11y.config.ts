export default {
  preset: '../../jest.preset.js',
  testPathIgnorePatterns: ['/node_modules/'],
  testMatch: ['**/*.a11y.spec.ts'],
  setupFiles: ['@angular/localize/init'],
  setupFilesAfterEnv: ['<rootDir>/src/test-setup.a11y.ts'],
  transform: {
    '^.+\\.(ts|mjs|js|html)$': [
      'jest-preset-angular',
      {
        tsconfig: '<rootDir>/tsconfig.spec.json',
        stringifyContentPathRegex: '\\.(html|svg)$',
      },
    ],
  },
  transformIgnorePatterns: ['node_modules/(?!.*\\.mjs$)']
};
