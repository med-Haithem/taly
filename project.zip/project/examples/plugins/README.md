# Plugins

This recipe contains a couple of example plugin libraries in the `libs` folder. It also contains an app configuration that uses these plugin libraries. To see how this is done take a look at the `plugins` section in `my-app-with-plugins/config/pages.json`.

For detailed documentation about the TALY plugins feature, check the [TALY documentation](https://taly.frameworks.allianz.io/additional-documentation/plugins.html)

### How to Run This Recipe

- In your terminal, go to the plugins recipe folder: `cd examples/plugins`
- Make sure you installed the dependencies of this recipe using `npm install --legacy-peer-deps`
- Start the fake backend with this command using `npm run start-backend`
- Generate and serve the app using `npm start`
- Open the application at http://localhost:4200

### The Example Plugins in This Recipe

This recipe contains example plugins that provide interceptors, validators and a PFE action.
The browser's JavaScript Console of the served application will contain some plugin-related output.

#### Interceptors

The library `interceptor-plugins-lib` contains the following interceptor plugins:

- **Auth Interceptor:** This plugin provides an interceptor that attaches an "Authorization" header to outgoing network requests. The header consists of a token type and a token that can be passed via plugin options in the `pages.json`. The way this is built will most certainly not work for real-world scenarios (static token). This plugin mostly serves the purpose of showing how to handle plugin options.
- **Language Interceptor:** This plugin provides an interceptor that attaches a "Language" header to outgoing network requests. The header can be passed via the configurable plugin options. If not given the interceptor will fall back to using Angular's `LOCALE_ID` as the value for the header.
- **Logging Interceptor:** The interceptor provided by this plugin only logs the headers of the outgoing network request without altering the request itself. The purpose of this plugin is to show how plugins that don't accept options could look like

#### Validators

The library `validator-plugins-lib` contains the following validator plugins:

- **thai-id-number-validator:** This plugin provides a sync validator that will check if a form field contains a valid Thailand ID number.
- **escaped-max-length:** This plugin implements a validator that checks if the length of the escaped string provided in a form input exceeds a certain limit. This maximum length is provided via configuration in `pages.json`.

Additionally, the example Building Block library (`plugins-recipe-building-blocks`) created in this recipe also defines plugins in a secondary entry point, under `/libs/plugins-recipe-building-blocks/plugins/`. This entry point defines one additional plugin:

- **postal-code-validator:** The async validator provided by this plugin will make a request to the mock backend, providing the input value in the request body. Based on the response provided by the backend, the validator decides if the input value is a valid postal code or not.

#### PFE Action

This plugin provides a PFE action that can be used in the `pfe.json`. The action itself merely adds some meaningless data to the PFE state. The purpose of this plugin is to showcase how PFE actions can be registered by a plugin and how the PFE state can be read/manipulated by a plugin.

### Notes about the Generated App

The example app that uses the plugin libraries mainly consists of three pages: "Http interceptors", "Custom validators" and "Issuance".

The "HTTP interceptors" page only serves the purpose of firing a network request so that it gets more obvious what the interceptors actually do. We added a fake backend so that you can inspect the requests even on the receiving side if you like. Since the login process itself does not play any role in the application (apart from the network request) you can "login" without providing any credentials, simply click the "Login" button to continue to the next page.

The "Custom validators" page instantiates an example Building Block (part of the library `plugins-recipe-building-blocks` included in this recipe) that implements a simple form. This page shows how both sync and async validator plugins work in a generated application. To display the error messages, the Building Block uses the validation errors component from `@allianz/taly-common/ui`, though any other approach could be used for that.

#### Interceptors

Some of the provided interceptors alter the outgoing network requests. You can take a look at the network tab of your browser developer tools to see that the requests to `/login` (fired after you clicked on the "Login" button) are equipped with the additional headers "Authorization" and "Language".

#### PFE Actions

The provided PFE action that is executed when entering the "Issuance" page adds "dummyData" to the PFE state. You can verify this by looking at the PFE state in the PFE debugger.

#### Validators

When entering the "Custom validators" page, you will see a form with these fields:

- Thai ID Number: a valid ID number is already set in the input field for convenience. You can modify its value to see the validation in action.
- Postal Code: the validation error is shown as soon as you write something in the field. This field is validated asynchronously. If you open the network tab of your browser developer tools, you can see that every change to the postal code value triggers a request to the mock backend.
- Street Name: set the value of this field, and when reaching the length specified via configuration a validation error will be shown.

##### Validation Param in "Street Name" Form Field

The recipe is setting the validation param in the Building Block level. Testing steps:

- Add the validation param in the plugin options above in `pages.json`. The validator should still use the value in the form field level, as it is the more specific
- Now remove `validationParam` from the validator configuration. The value provided in the options is now used by the validator
- Last, remove also the value provided via plugin options. In this case, as no validation parameter is provided via configuration, the default value defined internally in the plugin is used

##### i18n for Validation Error Messages

- Run the app for `es` locale: `npx nx run my-app-with-plugins:develop:es`
- When loading the "Custom validators" page, add some content to the "Postal Code" input field and leave it empty afterward. You will see that the `required` error message for that field is shown in the Spanish language

### Extracting Plugin Metadata

You can extract Plugins metadata from dedicated Plugin Libraries or from other libraries (e.g. Building Block libraries) that add Plugins in a secondary entry point of the library. Run the following command to extract the metadata of all libraries:

```bash
npx nx run-many --target=extract-plugin-metadata --all=true
```

The produced metadata file will be stored in the root folder of the respective library with the name `plugin-metadata.json`.
