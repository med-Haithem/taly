const express = require("express");
const cors = require("cors");

const app = express();
app.use(express.json()) // for parsing application/json
app.use(cors());

app.post("/login", (req, res) => {
  console.log(req.headers);
  res.send({});
});

app.post("/validate-postal-code", (req, res) => {
  const postalCodeRegExp = new RegExp(/^\d{5}$/);
  const value = req.body.inputValue;
  const isValid = postalCodeRegExp.test(value);
  const error = isValid ? null : "format error";
  res.send({ error });
});

const port = 3000;
app.listen(port, () =>
  console.log(`Plugins Mock-BFF listening at http://localhost:${port}...`)
);
