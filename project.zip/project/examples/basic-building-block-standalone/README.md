# Basic Building Block Standalone

Plain Angular Application with a Building Block.

```sh
# Install the dependencies
npm install --legacy-peer-deps

# Start the application
npm start

# Now open http://localhost:4200/
```

## Standalone Usage

The standalone use case is not officially supported but is technically possible. For orientation
check how [pfe-facade.ts](https://github.developer.allianz.io/ilt/taly-workspace/blob/6fbea6830644614ef32f265292b5c4cc8c245d81/libs/pfe-connector/src/lib/pfe-facade.ts) interacts with a Building Block.

There are events for the state being changed, business events that might be triggered and the signal if a Building Block is complete (either always or when the internal form is valid for example).
