import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { SummaryPanelModule } from '@allianz/taly-common/ui';
import { PlaceholderModule } from '@allianz/building-blocks';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CHANNEL, CHANNEL_TOKEN } from '@allianz/taly-core';
import { HttpClientModule } from '@angular/common/http';
import { AclInspectorService, AclService } from '@allianz/taly-acl/angular';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    PlaceholderModule,
    HttpClientModule,
    SummaryPanelModule,
    BrowserAnimationsModule,
  ],
  providers: [
    {
      provide: CHANNEL_TOKEN,
      useValue: CHANNEL.EXPERT,
    },
    // Currently, these two services have to be declared manually for standalone usage:
    AclService,
    AclInspectorService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
