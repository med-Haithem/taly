import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styles: [`
    :host {
        display: block;
        padding: 20px;
    }
    .container {
        max-width: 1200px;
        margin: auto;
    }
  `]
})
export class AppComponent {}
