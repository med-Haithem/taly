import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { NdbxIconModule } from "@allianz/ngx-ndbx/icon";
import {
  ACL_POLICY_CONTENT_TOKEN,
  AclInspectorService,
  AclModule,
  AclService,
} from "@allianz/taly-acl/angular";
import { InputElementInjectorModule } from "@allianz/taly-acl/input-element-injector-directive";
import { ReactiveFormsModule } from "@angular/forms";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { AppComponent } from "./app.component";

const POLICY_CONTENT = `
# hide the machine's sun button
weather/machine/sun,, hidden

# hide the back to Normal Button
weather/machine/normal,, hidden

# Oh this rule has the effect, that the \"back to normal\" button is disabled
# this works through a manual canEdit$ query on the service
# there is no template directive for this
weather/machine/normal,, disabled

# Oh we can reveal a monster that fits the dramatic weather
## monster-machine,, visible
## monster-machine/monster-type,, editable
## monster-machine/monster-name,, editable


# as everything is allowed by default let's sneak in some rules
# to stage our example
monster-machine,, hidden
monster-machine/monster-type,, disabled
monster-machine/monster-name,, readonly
`;
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    NdbxIconModule,
    NoopAnimationsModule,
    ReactiveFormsModule,
    AclModule,
    InputElementInjectorModule,
  ],
  providers: [
    {
      provide: ACL_POLICY_CONTENT_TOKEN,
      useValue: POLICY_CONTENT,
    },
    AclService,
    AclInspectorService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
