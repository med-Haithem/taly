# Basic Usage of ACL

This is a staged example & content which will guide you through the ACL usage in the template and code.

## Demonstration

There are two parts when you start the application:

+ Part 1 shows how you use the structural directive `*aclTag` to show & hide parts in the template. You can also see how to disable for example a button through a manual binding.

+ Part 2 shows how you can conveniently bind (which means reacting to ACL rules) a form to ACL with the `autoFormBindingFactory()` utility.

The best way you can use this recipe is to start the Angular application and go through the application. Then read the sources (class & template) to get a better understanding of what's going on.

Afterward, you might want to read the [ACL Guide](https://gdf-taly-workspace.azureedge.net/additional-documentation/acl.html) to get a better understanding of what you can do with ACL.

Let's start:

```sh
npm install
npm start
```

![](preview.png)
