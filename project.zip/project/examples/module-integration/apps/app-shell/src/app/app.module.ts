import { NdbxIconModule } from '@allianz/ngx-ndbx/icon';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NxHeaderModule } from '@aposin/ng-aquila/header';
import { NxHeadlineModule } from '@aposin/ng-aquila/headline';
import { NxLinkModule } from '@aposin/ng-aquila/link';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import dayjs from 'dayjs';
import localeData from 'dayjs/plugin/localeData';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import localizedFormat from 'dayjs/plugin/localizedFormat';
import utc from 'dayjs/plugin/utc';
dayjs.extend(localeData);
dayjs.extend(customParseFormat);
dayjs.extend(localizedFormat);
dayjs.extend(utc);
import 'dayjs/locale/en';
import { HttpClientModule } from '@angular/common/http';
import { PfeTrackingModule } from '@allianz/ngx-pfe/tracking';
import { NGX_PFE_CONFIGURATION } from '@allianz/ngx-pfe';
dayjs.locale('en');

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    NdbxIconModule,
    NxHeadlineModule,
    NxHeaderModule,
    NxLinkModule,
    // PfeTrackingModule,
  ],
  // providers: [
  //   {
  //     provide: NGX_PFE_CONFIGURATION,
  //     useValue: {
  //       tracking: {
  //         adobeUrl: 'my-adobe-url',
  //         appName: 'my-parent-app-name',
  //       },
  //     },
  //   },
  // ],
  bootstrap: [AppComponent],
})
export class AppModule {}
