import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./awesome-feature/awesome-feature.module').then(
        (m) => m.AwesomeFeatureModule
      ),
  },
  {
    path: 'customerjourney',
    loadChildren: () =>
      import('@allianz/customer-journey').then(
        (m) => m.EntryModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { initialNavigation: 'enabledBlocking' })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
