import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AwesomeFeatureRoutingModule } from './awesome-feature-routing.module';
import { AwesomeFormComponent } from './awesome-form/awesome-form.component';
import { NxHeadlineModule } from '@aposin/ng-aquila/headline';
import { NxCopytextModule } from '@aposin/ng-aquila/copytext';

@NgModule({
  declarations: [AwesomeFormComponent],
  imports: [
    CommonModule,
    AwesomeFeatureRoutingModule,
    NxHeadlineModule,
    NxCopytextModule,
  ],
  exports: [AwesomeFormComponent],
})
export class AwesomeFeatureModule {}
