import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'taly-awesome-form',
  templateUrl: './awesome-form.component.html',
  styleUrls: ['./awesome-form.component.scss']
})
export class AwesomeFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
