# Customer Journey Module Integration Recipe

This recipe offers an example of a Micro Frontend integration in build time. It features a TALY customer journey generated as a module. This generated journey is integrated directly into the routing of an app shell.

[See also, the module integration section in the TALY documentation](https://gdf-taly-workspace.azureedge.net/additional-documentation/app-generation/app-as-library.html)

## Quick start

### 1. Install the Dependencies

```sh
npm install --legacy-peer-deps
```

### 2. Generate the Journey Module

```sh
npm run generate-journey
# you can activate "watch mode" to continuously regenerate the journey whenever the configuration files change:
npm run generate-journey -- --watch
```

### 3. Run the App

```sh
# (use a new terminal if you are generating the journey in "watch mode")
npm run start
```
