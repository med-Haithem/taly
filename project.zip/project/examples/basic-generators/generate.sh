#!/usr/bin/env bash
npx taly generate-journey \
--name="my-taly-journey" \
--aquila-channel="expert" \
--directory=generated \
--env BFF_BASE_URL=https://api-test.allianz.com/itmp-bff-quote-and-buy-integration \
--config-directory=config/ \
--debug-helpers \
--ts-strict-mode \
--legacy-dependency-resolution \
"$@" # $@ forwards any additional given parameter

# The `legacy-dependency-resolution` flag causes the missing dependency error, so we have to install it manually.
cd generated && npm i @allianz/plugins --legacy-peer-deps
