## Basic Generators

A basic example of how to use the TALY generator to generate a flow-based application ("journey") based on PFE & TALY and your share of Building Blocks.

- `config/pages.json`: This is the main driver of the generation. Holds the Page & Building Block structure & data. The `json` file links to a schema definition that supports you in authoring & validating the file.
- `config/pfe.json`: A matching PFE configuration. This file is not evaluated but copied in and used by the provided PFE setup.
- `config/policy.txt`: The rules for the internal ACL setup which allows you to adjust any exposed resources in terms of visibility and editability. Exposed resources can be headlines, paragraphs, images and of course any sort of form element. The author of a Building Block must implement ACL to support it on the API side.
- `config/assets/`: put in any assets you refer to in `pages.json` (like for the stage). The folder will be made available in the generated application.

## Getting started

- Install the dependencies:
  ```sh
  npm install
  ```

- Generate & start the app:
  ```sh
  npm run start
  ```

- (optional) Start a watcher to regenerate the app whenever you change files in `config/`.
  ```sh
  npm run generate:watch
  ```
  Note that this requires you to separately serve the app:
  ```sh
  npm run serve-generated-app
  ```

## Turn your application into a web component

TALY's `workspace-with-journey` generator makes it extremely simple to create a web component. You can add the following option to your generator command, and then you are good to go. 🚀

```
--target=webcomponent
```

For more details, please refer to the [TALY documentation](https://gdf-taly-workspace.azureedge.net/additional-documentation/app-generation/app-as-web-component.html#generate-a-journey-as-web-component-outside-of-an-nx-workspace).
