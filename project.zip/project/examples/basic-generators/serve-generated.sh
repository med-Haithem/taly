#!/usr/bin/env bash
(cd generated && npx nx serve-generated-app my-taly-journey)